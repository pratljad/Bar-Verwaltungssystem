#!/bin/bash

rm -rf ./bin
rm -rf ./doc
rm -rf ../libs

mkdir ./bin
mkdir ./doc
mkdir ../libs

javac -sourcepath ./data -d bin -cp /opt/apache-tomcat/lib/mysql-connector-java.jar ./data/ConnectionFactory.java
javac -sourcepath ./data -d bin -cp /opt/apache-tomcat/lib/mysql-connector-java.jar ./data/QueryManager.java
jar -cfv ../libs/CF.jar -C ./bin .
javac -sourcepath ./data -d bin -cp ../libs/CF.jar:/opt/apache-tomcat/lib/mysql-connector-java.jar ./data/Database.java
jar -cfv ../libs/ConnectionFactory.jar -C ./bin .
rm -rf ../libs/CF.jar

