package data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class QueryManager {
	private static QueryManager myQueryManager = null;
	private static PreparedStatement preparedQuery = null;
	
	private QueryManager() {
		
	}
	
	public static QueryManager getInstance() {
		if(myQueryManager == null) {
			myQueryManager = new QueryManager();
		}
		return myQueryManager;
	}
	
	public static ResultSet getResultSetWithPreparedStatement(Connection currentConnection, String query) throws SQLException {
		preparedQuery = currentConnection.prepareStatement(query);
		ResultSet myResultSet = preparedQuery.executeQuery();
		preparedQuery.close();
		if(myResultSet != null) {
			return myResultSet;
		}
		
		else {
			throw new SQLException("Could not get result set. Processing Query failed.");
		}
	}
	
	public static ResultSet getResultSet(Connection currentConnection, Statement statementToExecute, String query) throws SQLException {
		ResultSet myResultSet = statementToExecute.executeQuery(query);
		if(myResultSet != null) {
			return myResultSet;
		}
		else {
			throw new SQLException("Could not get result set. Processing Query failed.");
		}
	}
}
