package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Database {
	private String       table  = "Person";      // MySQL is case-sensitive
	private static String user = "pupil";
	private static String pwd = "pupil";
	private static String url = "jdbc:mysql://localhost:3306/a05";
	private static String driver = "com.mysql.jdbc.Driver";
	private static String host = "localhost";
	private static String db = "A05";        // schema name
	private Connection   conn   = null;
	private ResultSet    rs     = null;
	private final static String nl   = System.getProperty("line.separator");

	public Database(){
	/*	try{
			ConnectionFactory.savePropertieFile();
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}*/
	}

	
	public ResultSet getRs() {
		return rs;
	}


	public void setRs(ResultSet rs) {
		this.rs = rs;
	}


	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public static String getDb() {
		return db;
	}

	public void setDb(String db) {
		this.db = db;
	}

	public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}
	  
	public ArrayList<String> executeStatment(String hostname,String url,String sql){
		ArrayList<String> returnList = new ArrayList<String>();
	    int updateCount;

	    //ConnectionFactory.createPropertieFile();
	    returnList.add("load/register Oracle drivers ..." +nl);
	    try {
	        Class.forName("org.postgresql.Driver");
	        // DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

	        returnList.add("get connection by url=" +url +" and user=" +this.getUser() +", pwd=*** ..." +nl);
	        this.setConn(DriverManager.getConnection(url));

	        returnList.add("create statement using a TYPE_SCROLL_INSENSITIVE and CONCUR_UPDATABLE resultset ..." +nl);
	        Statement stmt = this.getConn().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                                          ResultSet.CONCUR_UPDATABLE);
	        returnList.add("execute '" +sql +"' ... " +nl);
	        rs = QueryManager.getResultSet(conn, stmt, sql);

	        returnList.add("successfully completed; return status = "+nl +nl);
	        stmt.close();
	        this.getConn().close();
	    } catch (Exception ex) {
	            returnList.add("exception caught:" +nl +ex +nl);
	            ex.printStackTrace();
	    }
		return returnList;
	}
	
	public ArrayList<String> selectStatment(String hostname,String url,String query){
		ArrayList<String> returnList = new ArrayList<String>();
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	        //ConnectionFactory.createPropertieFile();
	        this.setConn(ConnectionFactory.get());
	        
	        Statement stmt = this.getConn().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                                              ResultSet.CONCUR_UPDATABLE);
	        rs = QueryManager.getResultSet(conn, stmt, query);

	        boolean stop;
	        int idx;
	        String record;
	        while (rs.next()) {
                stop = false;
                idx = 0;
                record = "";
                while (!stop) {
                    try
                    {
                        record += rs.getObject(idx) + ",";
                        idx++;
                    }
                    
                    catch (Exception ex) {
                        stop = true;
                    }
	            }
	            
	            returnList.add(record);
	        }

	    } catch (Exception ex) {
	    	returnList.add("exception caught:" +nl +ex +nl);
	        System.out.println(ex.getMessage());
	    }
		return returnList;
	}


	public void deleteRow(int selectedRow, ResultSet rsd) {
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	        //ConnectionFactory.createPropertieFile();
	        //returnList.add("get connection by url=" +url +" and user=" +this.getUser() +", pwd=*** ..." +nl);
	        this.setConn(ConnectionFactory.get());
	        
	        Statement stmt = this.getConn().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                                              ResultSet.CONCUR_UPDATABLE);
	        rsd.beforeFirst();
	        int idx=0;
	        while (rsd.next()) {
	        	if(idx==selectedRow){
	        		rsd.deleteRow();
	        		break;
	        	}
	        	idx++;
	        }

	    } catch (Exception ex) {

	        System.out.println(ex.getMessage());
	    }
	}


	public void updateRow(ResultSet rsd, String columnName, int rowIndex, Object aValue) {
		try {
	        Class.forName("com.mysql.jdbc.Driver");
	        //ConnectionFactory.createPropertieFile();
	        this.setConn(ConnectionFactory.get());
	        
	        Statement stmt = this.getConn().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                                              ResultSet.CONCUR_UPDATABLE);
	        rsd.beforeFirst();
	        int idx=0;
	        while (rsd.next()) {
	        	if(idx==rowIndex){
	        		rsd.updateString(columnName, (String) aValue);
	        		rsd.updateRow();
	        		break;
	        	}
	        	idx++;
	        }

	    } catch (Exception ex) {

	        System.out.println(ex.getMessage());
	    }
	}
	
}

