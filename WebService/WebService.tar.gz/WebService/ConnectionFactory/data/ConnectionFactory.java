package data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class ConnectionFactory {
	private static String user;
	private static String pwd;
	private static String url;
	private static String driver;
	private static String host;
	private static String db;
	
	private static final String homedir = System.getProperty("user.home");
	private static final String fileseperator = System.getProperty("file.separator");
	private static final String propFileMySql = "CFMySqlDatabase.properties";
	private static final String propFileOracleIntern = "CFOracleDatabaseIntern.properties";
	private static final String propFileOracleExtern = "CFOracleDatabaseExtern.properties";

	private static ConnectionFactory conn = new ConnectionFactory();
		
	private ConnectionFactory(){
	}
	
	public static Connection get(String user, String pwd) throws SQLException {
        try
        {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, pwd);
        }
        catch(Exception ex)
        {
        }
        
        return null;
	}
	
	public static Connection get() throws SQLException {
        try
        {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, pwd);
        }
        catch(Exception ex)
        {
        }
        
        return null;
	}
	
	public static ConnectionFactory getConn() {
		return conn;
	}
	
	public static boolean close(ResultSet rs){
		try{
			rs.close();
			return true;
		}
		catch(Exception ignore){
			return false;
		}
	}
	
	public static boolean close(Connection con){
		try{
			con.close();
			return true;
		}
		catch(Exception ignore){
			return false;
		}
	}
	
	public static boolean close(Statement stmt) {
		try{
			stmt.close();
			return true;
		}
		catch(Exception ignore){
			return false;
		}
	}
	
	public static boolean savePropertieFile() {
        saveMySqlPropertieFile();
        saveInternOraclePropertieFile();
        saveExternOraclePropertieFile();
		return true;
	  }
	
	private static void saveMySqlPropertieFile() {
        Properties prop = new Properties();
        OutputStream output = null;
		try {
			output = new FileOutputStream(homedir + fileseperator + propFileMySql);
	
			prop.setProperty("driver", "com.jdbc.mysql.driver");
			prop.setProperty("url", "jdbc:mysql://localhost:3306/a05");
			prop.setProperty("user", "pupil");
			prop.setProperty("pwd", "pupil");
			prop.setProperty("host", "localhost");
			
			prop.store(output, null);
			output.close();
		} catch (Exception io) {
				io.printStackTrace();
		}
	}
	
	private static void saveInternOraclePropertieFile() {
        Properties prop = new Properties();
        OutputStream output = null;
		try {
			output = new FileOutputStream(homedir + fileseperator + propFileOracleIntern);
	
			prop.setProperty("driver", "oracle.jdbc.OracleDriver");
			prop.setProperty("url", "jdbc:oracle:thin:@192.168.128.152:1521:ora11g");
			prop.setProperty("user", "d5a05");
			prop.setProperty("pwd", "d5a");
			prop.setProperty("host", "aphrodite4");
			
			prop.store(output, null);
			output.close();
		} catch (Exception io) {
				io.printStackTrace();
		}
	}
	
	private static void saveExternOraclePropertieFile() {
        Properties prop = new Properties();
        OutputStream output = null;
		try {
			output = new FileOutputStream(homedir + fileseperator + propFileOracleExtern);
	
			prop.setProperty("driver", "oracle.jdbc.OracleDriver");
			prop.setProperty("url", "jdbc:oracle:thin:@212.152.179.117:1521:ora11g");
			prop.setProperty("user", "d5a05");
			prop.setProperty("pwd", "d5a");
			prop.setProperty("host", "aphrodite4");
			
			prop.store(output, null);
			output.close();
		} catch (Exception io) {
				io.printStackTrace();
		}
	}
		
	public static void loadPropertieFile(File pfile){
		Properties prop = new Properties();
		InputStream input = null;
		try{
			if (!pfile.exists())
				savePropertieFile();
			
			prop = new Properties();
			input = new FileInputStream(pfile.getPath());
			prop.load(input);
			
			driver=prop.getProperty("driver", "com.jdbc.mysql.driver");
			url = prop.getProperty("url", "jdbc:mysql://localhost:3306/a05");
			user = prop.getProperty("user", "pupil");
			pwd = prop.getProperty("pwd", "pupil");
			host = prop.getProperty("host", "localhost");
			String[] info = url.split("/");
			db = info[info.length-1];
			input.close();
		}
		catch(IOException e){
			System.out.print("Error: " +e.getMessage());
		}
	}

	public static void createPropertieFile() {
		File f = new File(homedir + fileseperator + propFileMySql);
		System.out.println(f.getPath());
		if (!f.exists())
			savePropertieFile();
	}
	
	public static File getInternOracleDatabseFile() {
		return new File(homedir + fileseperator + propFileOracleIntern);
	}
	
	public static File getExternOracleDatabseFile() {
		return new File(homedir + fileseperator + propFileOracleExtern);
	}	
	
	public static File getMySqlFile() {
		return new File(homedir + fileseperator + propFileMySql);
	}
	
	
	public static String getUser() {
		return user;
	}
	public static String getPwd() {
		return pwd;
	}
	public static String getUrl() {
		return url;
	}
	public static String getDriver() {
		return driver;
	}
	public static String getHost() {
		return host;
	}
	public static String getHomedir() {
		return homedir;
	}
	public static String getFileseperator() {
		return fileseperator;
	}
	public static String getDb() {
		return db;
	}

}
