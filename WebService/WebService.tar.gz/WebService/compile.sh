#!/bin/bash

cd ./ConnectionFactory
./compile.sh

cd ../WebService_Barverwaltung
./compile.sh
