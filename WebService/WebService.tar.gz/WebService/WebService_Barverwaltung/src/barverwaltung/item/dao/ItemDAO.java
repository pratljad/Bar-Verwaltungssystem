package barverwaltung.item.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import barverwaltung.item.model.*;
import data.*;

public enum ItemDAO {
	instance;
	
	private String select = "SELECT * FROM ";
	private String table = "Item";
	private Map<Integer, Item> contentProvider = new HashMap<Integer, Item>();
	
	private ItemDAO() {
		try { readDataFromOracleDatabase(select + table); } catch (SQLException e) { e.printStackTrace(); }
		
		//contentProvider.put(1, new Item(1, "Shisha", "classic", 9.80));
		//contentProvider.put(2, new Item(2, "Drink", "Kiwi Pago", 3.60));
		//contentProvider.put(3, new Item(3, "Food", "Toast", 2.50));
		//contentProvider.put(4, new Item(4, "Toobaco", "Adalja", 0));
	}
	
	private void readDataFromOracleDatabase(String query) throws SQLException {
		Connection conn = null;
		//ConnectionFactory.loadPropertieFile(ConnectionFactory.getInternOracleDatabseFile());
    	//conn = ConnectionFactory.get();
    	if (conn == null) {
    		ConnectionFactory.loadPropertieFile(ConnectionFactory.getExternOracleDatabseFile());
        	conn = ConnectionFactory.get();
    	}
    	
    	if (conn == null)
    		throw new SQLException("No Database Connection");
    	
		Statement stmt = conn.createStatement();
        ResultSet rs = QueryManager.getResultSet(conn, stmt, query);
        ResultSetMetaData md = rs.getMetaData();
        
        int columnCount = md.getColumnCount();
        String[] columns = new String[columnCount];
        
        for(int i = 0; i < columnCount; i++) {
        	columns[i] = md.getColumnName(i+1);
        }
		
        contentProvider.clear();
        //Fill table
        while (rs.next()) {
        	Item newItem = new Item();
        	for (int j = 0; j < columnCount; j++) {
        		if (j == 0)
        			newItem.setId(Integer.parseInt(rs.getString(j+1)));
        		
        		else if (j == 1)
        			newItem.setCatagory(rs.getString(j+1));
        		
        		else if (j == 2)
        			newItem.setDescription(rs.getString(j+1));
        		
        		else if (j == 3)
        			newItem.setPrice(Double.parseDouble(rs.getString(j+1)));
        	}
        	contentProvider.put(newItem.getId(), newItem);
        }
	}
	
	public Map<Integer, Item> getModel() { 
		try { readDataFromOracleDatabase(select + table); } catch (SQLException e) { e.printStackTrace(); }
		return contentProvider; }
	
	public void AddItem(Item ItemToAdd) {
		if (ItemToAdd != null) {
			contentProvider.put(ItemToAdd.getId(), ItemToAdd);
		}
	}
	
	public Item RemoveItem(Item ItemToRemove) {
		return contentProvider.remove(ItemToRemove.getId());
	}
}
