package barverwaltung.item.resources;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import barverwaltung.item.dao.ItemDAO;
import barverwaltung.item.model.Item;


// maps the resource to the URL items
@Path("/items")
public class ItemsResource {

	// Allows to insert contextual objects into the class, 
	  // e.g. ServletContext, Request, Response, UriInfo
	  @Context
	  UriInfo uriInfo;
	  @Context
	  Request request;


	  // Return a list of items for a user in a browser
	  @GET
	  @Produces(MediaType.TEXT_XML)
	  public List<Item> getItemsBrowser() {
	    List<Item> items = new ArrayList<Item>();
	    items.addAll(ItemDAO.instance.getModel().values());
	    return items; 
	  }
	  
	  // Return a list of items for applications
	  @GET
	  @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	  public List<Item> getItems() {
	    List<Item> items = new ArrayList<Item>();
	    items.addAll(ItemDAO.instance.getModel().values());
	    return items; 
	  }
	  
	  
	  // retuns the number of items
	  // Use http://localhost:8080/WebServiceBarverwaltung/rest/items/count
	  // to get the number of elements/records/tuples
	  @GET
	  @Path("count")
	  @Produces(MediaType.TEXT_PLAIN)
	  public String getCount() {
	    int count = ItemDAO.instance.getModel().size();
	    return String.valueOf(count);
	  }
	  
	  @POST
	  @Produces(MediaType.TEXT_HTML)
	  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	  public void newItem(@FormParam("id") int id,
	      @FormParam("category") String category,
	      @FormParam("description") String description,
	      @FormParam("price") double price,
	      @Context HttpServletResponse servletResponse) throws IOException {
	    Item item = new Item(id, category, description, price);
	    ItemDAO.instance.getModel().put(id, item);
	    
	    servletResponse.sendRedirect("../CreateItem.html");
	  }
	  
	  
	  // Defines that the next path parameter after items is
	  // treated as a parameter and passed to the ItemResources
	  // Allows to type http://localhost:8080/WebServiceBarverwaltung/rest/items/5014
	  // 5014 will be treated as parameter item and passed to ItemResource
	  @Path("{item}")
	  public ItemResource getItem(@PathParam("item") int id) {
	    return new ItemResource(uriInfo, request, id);
	  }
	  	
	
}
