package barverwaltung.item.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.xml.bind.JAXBElement;

import barverwaltung.item.dao.ItemDAO;
import barverwaltung.item.model.Item;

/** Resource for a single item object. */
public class ItemResource {
	  @Context
	  UriInfo uriInfo;
	  @Context
	  Request request;
	  int     id;
	  public ItemResource(UriInfo uriInfo, Request request, int id) {
	    this.uriInfo = uriInfo;
	    this.request = request;
	    this.id    = id;
	  }
	  
	  //Application integration     
	  @GET
	  @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	  public Item getItem() {
		Item p = ItemDAO.instance.getModel().get(id);
	    if (p == null) throw new RuntimeException("Get: Item with id=" + id +  " not found");
	    return p;
	  }
	  
	  // For the browser
	  @GET
	  @Produces(MediaType.TEXT_XML)
	  public Item getItemHTML() {
	    Item p = ItemDAO.instance.getModel().get(id);
	    if (p == null) throw new RuntimeException("Get: Item with id=" + id +  " not found");
	    return p;
	  }
	  
	  @PUT
	  @Consumes(MediaType.APPLICATION_XML)
	  public Response putItem(JAXBElement<Item> item) {
	    // Item p = item.getValue();
	    return putAndGetResponse(item.getValue());
	  }
	  
	  @DELETE
	  public void deleteItem() {
	    // Item p = ItemDAO.instance.getModel().remove(id);
	    if (ItemDAO.instance.getModel().remove(id) == null) throw new RuntimeException("Delete: Item with id=" + id +  " not found");
	  }
	  
	  private Response putAndGetResponse(Item item) {
	    Response res = null;
	    if (ItemDAO.instance.getModel().containsKey(item.getId())) {
	      res = Response.noContent().build();
	    } else {
	      res = Response.created(uriInfo.getAbsolutePath()).build();
	    }
	    ItemDAO.instance.getModel().put(item.getId(), item);
	    return res;
	  }  
}
