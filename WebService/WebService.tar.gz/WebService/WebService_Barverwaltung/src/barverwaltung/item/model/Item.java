package barverwaltung.item.model;

public class Item {
	private int id;
	private String category;
	private String description;
	private double price;
	
	public Item() {
		
	}
	
	public Item(int id, String category, String description, double price) {
		super();
		this.id = id;
		this.category = category;
		this.description = description;
		this.price = price;
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getCatagory() {
		return category;
	}
	
	public void setCatagory(String category) {
		this.category = category;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
}
