package barverwaltung.tobacco.resources;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import barverwaltung.tobacco.dao.TobaccoDAO;
import barverwaltung.tobacco.model.Tobacco;


// maps the resource to the URL tobaccos
@Path("/tobaccos")
public class TobaccosResource {

	// Allows to insert contextual objects into the class, 
	  // e.g. ServletContext, Request, Response, UriInfo
	  @Context
	  UriInfo uriInfo;
	  @Context
	  Request request;


	  // Return a list of tobaccos for a user in a browser
	  @GET
	  @Produces(MediaType.TEXT_XML)
	  public List<Tobacco> getTobaccosBrowser() {
	    List<Tobacco> tobaccos = new ArrayList<Tobacco>();
	    tobaccos.addAll(TobaccoDAO.instance.getModel().values());
	    return tobaccos; 
	  }
	  
	  // Return a list of tobaccos for applications
	  @GET
	  @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	  public List<Tobacco> getTobaccos() {
	    List<Tobacco> tobaccos = new ArrayList<Tobacco>();
	    tobaccos.addAll(TobaccoDAO.instance.getModel().values());
	    return tobaccos; 
	  }
	  
	  
	  // retuns the number of tobaccos
	  // Use http://localhost:8080/WebServiceBarverwaltung/rest/tobaccos/count
	  // to get the number of elements/records/tuples
	  @GET
	  @Path("count")
	  @Produces(MediaType.TEXT_PLAIN)
	  public String getCount() {
	    int count = TobaccoDAO.instance.getModel().size();
	    return String.valueOf(count);
	  }
	  
	  @POST
	  @Produces(MediaType.TEXT_HTML)
	  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	  public void newTobacco(@FormParam("id") int id,
	      @FormParam("description") String description,
	      @FormParam("extant") String extant,
	      @Context HttpServletResponse servletResponse) throws IOException {
	    Tobacco tobacco = new Tobacco(id, description, extant);
	    TobaccoDAO.instance.getModel().put(id, tobacco);
	    
	    servletResponse.sendRedirect("../CreateTobacco.html");
	  }
	  
	  
	  // Defines that the next path parameter after tobaccos is
	  // treated as a parameter and passed to the TobaccoResources
	  // Allows to type http://localhost:8080/WebServiceBarverwaltung/rest/tobaccos/5014
	  // 5014 will be treated as parameter tobacco and passed to TobaccoResource
	  @Path("{tobacco}")
	  public TobaccoResource getTobacco(@PathParam("tobacco") int id) {
	    return new TobaccoResource(uriInfo, request, id);
	  }
	  	
	
}
