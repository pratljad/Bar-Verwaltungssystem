package barverwaltung.tobacco.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.xml.bind.JAXBElement;

import barverwaltung.tobacco.dao.TobaccoDAO;
import barverwaltung.tobacco.model.Tobacco;

/** Resource for a single tobacco object. */
public class TobaccoResource {
	  @Context
	  UriInfo uriInfo;
	  @Context
	  Request request;
	  int     id;
	  public TobaccoResource(UriInfo uriInfo, Request request, int id) {
	    this.uriInfo = uriInfo;
	    this.request = request;
	    this.id    = id;
	  }
	  
	  //Application integration     
	  @GET
	  @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	  public Tobacco getTobacco() {
		Tobacco p = TobaccoDAO.instance.getModel().get(id);
	    if (p == null) throw new RuntimeException("Get: Tobacco with id=" + id +  " not found");
	    return p;
	  }
	  
	  // For the browser
	  @GET
	  @Produces(MediaType.TEXT_XML)
	  public Tobacco getTobaccoHTML() {
	    Tobacco p = TobaccoDAO.instance.getModel().get(id);
	    if (p == null) throw new RuntimeException("Get: Tobacco with id=" + id +  " not found");
	    return p;
	  }
	  
	  @PUT
	  @Consumes(MediaType.APPLICATION_XML)
	  public Response putTobacco(JAXBElement<Tobacco> tobacco) {
	    // Tobacco p = tobacco.getValue();
	    return putAndGetResponse(tobacco.getValue());
	  }
	  
	  @DELETE
	  public void deleteTobacco() {
	    // Tobacco p = TobaccoDAO.instance.getModel().remove(id);
	    if (TobaccoDAO.instance.getModel().remove(id) == null) throw new RuntimeException("Delete: Tobacco with id=" + id +  " not found");
	  }
	  
	  private Response putAndGetResponse(Tobacco tobacco) {
	    Response res = null;
	    if (TobaccoDAO.instance.getModel().containsKey(tobacco.getId())) {
	      res = Response.noContent().build();
	    } else {
	      res = Response.created(uriInfo.getAbsolutePath()).build();
	    }
	    TobaccoDAO.instance.getModel().put(tobacco.getId(), tobacco);
	    return res;
	  }  
}
