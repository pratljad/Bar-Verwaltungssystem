package barverwaltung.tobacco.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import barverwaltung.tobacco.model.*;
import data.*;

public enum TobaccoDAO {
	instance;
	
	private String select = "SELECT * FROM ";
	private String table = "Tobacco";
	private Map<Integer, Tobacco> contentProvider = new HashMap<Integer, Tobacco>();
	
	private TobaccoDAO() {
		try { readDataFromOracleDatabase(select + table); } catch (SQLException e) { e.printStackTrace(); }
	}
	
	private void readDataFromOracleDatabase(String query) throws SQLException {
		Connection conn = null;
		//ConnectionFactory.loadPropertieFile(ConnectionFactory.getInternOracleDatabseFile());
    	//conn = ConnectionFactory.get();
    	if (conn == null) {
    		ConnectionFactory.loadPropertieFile(ConnectionFactory.getExternOracleDatabseFile());
        	conn = ConnectionFactory.get();
    	}
    	
    	if (conn == null)
    		throw new SQLException("No Database Connection");
    	
		Statement stmt = conn.createStatement();
        ResultSet rs = QueryManager.getResultSet(conn, stmt, query);
        ResultSetMetaData md = rs.getMetaData();
        
        int columnCount = md.getColumnCount();
        String[] columns = new String[columnCount];
        
        for(int i = 0; i < columnCount; i++) {
        	columns[i] = md.getColumnName(i+1);
        }
		
        contentProvider.clear();
        //Fill table
        while (rs.next()) {
        	Tobacco newTobacco = new Tobacco();
        	for (int j = 0; j < columnCount; j++) {
        		if (j == 0)
        			newTobacco.setId(Integer.parseInt(rs.getString(j+1)));
        		
        		else if (j == 1)
        			newTobacco.setDescription(rs.getString(j+1));
        		
        		else if (j == 2) {
        			double extant = Double.parseDouble(rs.getString(j+1));
        			if (extant == 0)
        				newTobacco.setExtant("NO");
        			else
        				newTobacco.setExtant("YES");
        		}
        	}
        	contentProvider.put(newTobacco.getId(), newTobacco);
        }
	}
	
	public Map<Integer, Tobacco> getModel() { 
		try { readDataFromOracleDatabase(select + table); } catch (SQLException e) { e.printStackTrace(); }
		return contentProvider; }
	
	public void AddTobacco(Tobacco TobaccoToAdd) {
		if (TobaccoToAdd != null) {
			contentProvider.put(TobaccoToAdd.getId(), TobaccoToAdd);
		}
	}
	
	public Tobacco RemoveTobacco(Tobacco TobaccoToRemove) {
		return contentProvider.remove(TobaccoToRemove.getId());
	}
}
