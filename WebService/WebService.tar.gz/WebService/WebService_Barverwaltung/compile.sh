#!/bin/bash
cp ../libs/ConnectionFactory.jar ./WebContent/WEB-INF/lib
cp ./ojdbc6.jar ./WebContent/WEB-INF/lib

rm -rf ./build
rm -rf ./exportFolder
mkdir build build/classes

api=`echo ls ./jaxrs-ri/api/*.jar |sed 's/ /:/g'`
ext=`echo ls ./jaxrs-ri/ext/*.jar |sed 's/ /:/g'`
libs=`echo ls ./jaxrs-ri/lib/*.jar |sed 's/ /:/g'`
con=`echo ls ../libs/*.jar |sed 's/ /:/g'`

javac -sourcepath ./src/ -cp /opt/apache-tomcat/lib/servlet-api.jar:/opt/apache-tomcat/lib/mysql-connector-java.jar:./ojdbc6.jar:$api:$ext:$libs:$con -d ./build/classes ./src/barverwaltung/item/resources/ItemsResource.java

javac -sourcepath ./src/ -cp /opt/apache-tomcat/lib/servlet-api.jar:/opt/apache-tomcat/lib/mysql-connector-java.jar:./ojdbc6.jar:$api:$ext:$libs:$con -d ./build/classes ./src/barverwaltung/tobacco/resources/TobaccosResource.java

mkdir exportFolder
cp -r ./WebContent/META-INF ./exportFolder
cp -r ./WebContent/WEB-INF ./exportFolder
cp ./WebContent/index.html ./exportFolder
cp ./WebContent/CreateItem.html ./exportFolder
cp -r ./build/classes ./exportFolder/WEB-INF

cd ./exportFolder

jar -cvf "WebServiceBarverwaltung.war" .

cp ./"WebServiceBarverwaltung.war" /opt/apache-tomcat/webapps

firefox http://localhost:8080/"WebServiceBarverwaltung"/
